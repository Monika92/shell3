package jp.co.wap.exam; 

import java.util.List; 

import jp.co.wap.exam.lib.Interval; 

public class Problem1 { 

	public int getMaxIntervalOverlapCount(List<Interval> intervals) { 
		int numOverlap = 0;

		if( intervals == null || intervals.size() == 0){
			return 0;
		}
		
		int numSlots = 25;
		int minuteIndex1 = 4, minuteIndex2 = 3;

		//calculate number of slots to split [hourly, minutes]
		for(int i =0; i< intervals.size(); i++){	
			String minutes = intervals.get(i).getBegin();
			
			if(Integer.parseInt(""+minutes.charAt(minuteIndex1)) != 0 || 
					Integer.parseInt(""+minutes.charAt(minuteIndex2)) != 0 ){
				numSlots = 24*60 + 1;
				break;
			}
			minutes = intervals.get(i).getEnd();
			if(Integer.parseInt(""+minutes.charAt(minuteIndex1)) != 0 || 
					Integer.parseInt(""+minutes.charAt(minuteIndex2)) != 0 ){
				numSlots = 24*60 + 1;				
				break;
			}
		}

		int[] slotArray = new int[numSlots];
		for( int i = 0;i < numSlots; i++){
			slotArray[i] = 0;
		}
			
		
		for( int i = 0; i<intervals.size(); i++){		
			int beg = 0,end = 0;
			
			if(numSlots == 25){
				beg = intervals.get(i).getBeginHour();
				end = intervals.get(i).getEndHour();
								
			}
			else{
				beg = intervals.get(i).getBeginMinuteUnit();
				end = getEndMinuteUnit(intervals.get(i)) ;
			}

			for( int j = beg; j <= end ; j++){
				slotArray[j]++;
			}
		}
		
		numOverlap = slotArray[0];
		for( int i = 0; i<numSlots; i++){
			if(numOverlap < slotArray[i]){
				numOverlap = slotArray[i];
			}
		}
		
		if(numOverlap > 1){
			return numOverlap;
		}
		else {
			return 0;
		}

	} 
	
	//number of minutes until end time since 00:00
	public int getEndMinuteUnit(Interval i){
		return i.getEndHour()*60 + i.getEndMinute();
	}
	
} 
