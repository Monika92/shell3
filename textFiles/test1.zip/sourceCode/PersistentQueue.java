package jp.co.wap.exam; 

import java.util.LinkedList;
import java.util.NoSuchElementException; 

/**
 * Implementing this queue using Java's LinkedList class would make it faster since 
 * arraylist requires resize when capacity is reached and therefore an extra copy would be required
 * Linked list doesnt require that.
 * Delete in LinkedList is O(1) as compared to ArrayList's O(n)
 * Peek in LinkedList is O(1) as well.
 */



/** 
 *	The Queue class represents an immutable first-in-first-out (FIFO) queue of objects. 
 *	@param <E> 
 */ 

public class PersistentQueue<E> {  

	private LinkedList<E> queue; 
	/** 
	 *	requires default constructor. 
	 */ 
	public PersistentQueue() {  
		queue = new LinkedList<E>(); 
	} 

	private PersistentQueue(LinkedList<E> queue) { 	
		this.queue = queue; 
	} 

	/** 
	 *	Returns the queue that adds an item into the tail of this queue without modifying this queue. 
	 *	<pre>  	 *  e.g. 
	 *	When this queue represents the queue (2, 1, 2, 2, 6) and we enqueue the value 4 into this queue,  	 
	 *    this method returns a new queue (2, 1, 2, 2, 6, 4) 
	 *	and this object still represents the queue (2, 1, 2, 2, 6) . 
	 *	</pre> 
	 *	If the element e is null, throws IllegalArgumentException. 
	 *	@param e 
	 *	@return 
	 *	@throws IllegalArgumentException 
	 */ 
	public PersistentQueue<E> enqueue(E e) {  	 	 	
		if (e == null) { 
			throw new IllegalArgumentException(); 
		} 
		LinkedList<E> clone = new LinkedList<E>(queue);  	 	
		clone.add(e); 
		
		return new PersistentQueue<E>(clone); 
	} 

	/** 
	 *	Returns the queue that removes the object at the head of this queue without modifying this queue. 
	 *	<pre>  	 *  e.g. 
	 *	When this queue represents the queue (7, 1, 3, 3, 5, 1) , 
	 *	this method returns a new queue (1, 3, 3, 5, 1) 
	 *	and this object still represents the queue (7, 1, 3, 3, 5, 1) . 
	 *	</pre> 
	 *	If this queue is empty, throws java.util.NoSuchElementException. 
	 *	@return 
	 *	@throws java.util.NoSuchElementException 
	 */ 
	public PersistentQueue<E> dequeue() {  	 		  	 	
		if (queue.isEmpty()) { 
			throw new NoSuchElementException(); 
		} 
		LinkedList<E> clone = new LinkedList<E>(queue);  	 	
		clone.remove();
		return new PersistentQueue<E>(clone); 
	} 

	/** 
	 *	Looks at the object which is the head of this queue without removing it from the queue. 
	 *	<pre>  	 *  e.g. 
	 *	When this queue represents the queue (7, 1, 3, 3, 5, 1), 
	 *	this method returns 7 and this object still represents the queue (7, 1, 3, 3, 5, 1) 
	 *	</pre> 
	 *	If the queue is empty, throws java.util.NoSuchElementException. 
	 *	@return 
	 *	@throws java.util.NoSuchElementException 
	 */ 
	public E peek() {  
		if (queue.isEmpty()) { 
			throw new NoSuchElementException(); 
		} 
		return queue.peek(); 
	} 

	/** 
	 *	Returns the number of objects in this queue. 
	 *	@return 
	 */ 
	public int size() { 
		return queue.size(); 
	} 
} 
