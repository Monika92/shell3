package jp.co.wap.exam; 

import java.util.Collections;
import java.util.Comparator;
import java.util.List; 

import jp.co.wap.exam.lib.Interval; 

public class Problem2{ 
		
	int[] closestIntervals; // array holding intervalIds of closest interval with finish time < startime of [idx]
	int[] maxTimeTable; // array holding memoized values
	
	public int getMaxWorkingTime(List<Interval> intervals) {  	 		 	
		int maxWorkingTime = 0;
		
		// if interval List is null or empty then return 0
		if(intervals == null || intervals.size() == 0){
			return 0;
		}
		
		//check if any interval is null
		for( int i = 0; i<intervals.size(); i++){
			if( intervals.get(i) == null){
				return 0;
			}
		}
		
		//if only 1 interval is present
		if(intervals.size() == 1){
			maxWorkingTime = getEndMinuteUnit(intervals.get(0)) - intervals.get(0).getBeginMinuteUnit();
			return maxWorkingTime;
		}
		
		//Sort the intervals based on increasing order of finishing time
		Collections.sort(intervals,new Comparator<Interval>() {

			@Override
			public int compare(Interval i1, Interval i2) {
				int hour1 = i1.getEndHour();
				int hour2 = i2.getEndHour();
				int min1 = i1.getEndMinute();
				int min2 = i2.getEndMinute();

				if (hour1 == hour2){
					if(min1 == min2){
						return 0;
					}
					else if(min1 > min2){
						return 1;
					}else{
						return -1;
					}
				}			
				else if (hour1 > hour2)
					return 1;
				else
					return -1;
			}
		});

		//initialize table values to -1
		int numIntervals = intervals.size();
		maxTimeTable = new int[numIntervals];
		for( int i = 0; i<intervals.size(); i++){
			maxTimeTable[i] = -1;
		}
		
		//initialize first value as interval one duration
		maxTimeTable[0] =  getEndMinuteUnit(intervals.get(0)) - intervals.get(0).getBeginMinuteUnit();
		
		//populate the closestInterval Array
		computeClosestInterval(intervals.size(), intervals);
		
		maxWorkingTime = getMaxWorkingTime(numIntervals, intervals);

		return maxWorkingTime;
	}
	
	public int getMaxWorkingTime(int numIntervals, List<Interval> intervals){

		for( int i = 0; i<numIntervals; i++){
			
			int intervalLength = getEndMinuteUnit(intervals.get(i)) - intervals.get(i).getBeginMinuteUnit();
			int rhs = 0, lhs = 0;
			if(i == 0){
				lhs = 0;
			}
			else{
				lhs = maxTimeTable[i-1];
			}
			
			if(closestIntervals[i] == -1){
				rhs = intervalLength;
			}
			else{
				rhs = intervalLength + maxTimeTable[closestIntervals[i]];
			}
			
			maxTimeTable[i] = getMax(lhs,rhs);
			System.out.println("maxTimeTable- " +i + " = " + maxTimeTable[i]);
		}		
        return maxTimeTable[numIntervals - 1];
	}
	
	public int getMax(int left, int right){
		if(left > right){
			return left;
		}
		else{
			return right;
		}
	}
	
	public void computeClosestInterval(int size, List<Interval> intervals){
		closestIntervals = new int[size];
		
		for(int i=0; i<intervals.size(); i++){
			Interval temp = intervals.get(i);
			int closestInterval = getClosestIntervalId(temp.getBeginMinuteUnit(), i-1,intervals);
			closestIntervals[i] = closestInterval;
				
		}
	}
	
	//binary search for closest interval with end time less than start time of current Interval 
	public int getClosestIntervalId(int startTime, int high, List<Interval> intervals){
		
		//for first interval
		if(high == -1)
			return -1;
		
		int low = 0, closestInt = -1;
		int mid, finishTime;
		
		while(low <= high){

            mid = (low + high) /2 ;
            finishTime = getEndMinuteUnit(intervals.get(mid));

            if (finishTime >= startTime){
                high = mid-1;
            }else{
                closestInt = mid;
                low = mid + 1;
            }
        }
        return closestInt;	
	}
	
	public int getEndMinuteUnit(Interval i){
		return i.getEndHour()*60 + i.getEndMinute();
	}
} 
